<?php
//entry point to our application to send in the requests
require "app/init.php";

new App\core\App();

?>