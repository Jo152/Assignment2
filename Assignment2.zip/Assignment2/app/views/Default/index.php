<html>
<head>
	<title>Default location for my application</title>
</head>
<body>
	<h1>Welcome, please login to continue</h1>
	<p><a href='<?= BASE ?>/Default/login'>Login</a></p>
</body>
</html>