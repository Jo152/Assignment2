<html>
<head>
	<title>Create a profile</title>
</head>
<body>
	<form method="post" action="">
        <label>First Name: <input type="text" name="first_name" /></label><br />
        <label>Middle Name: <input type="text" name="middle_name" /></label><br />
        <label>Last Name: <input type="text" name="last_name" /></label><br />

		<input type="submit" name="createProfile" value="Create Profile" />
	</form>
</body>
</html>